See randomshapes_demo.m and shark_demo.m for more information.

I recommend that you try to compile the CMEX code for the function computeH:
type 'mex computeH.c' in the Matlab Command Window ('mex computeH.c -l matlb' under Unix)
